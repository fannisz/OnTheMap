//
//  UdacitySessionResponse.swift
//  OnTheMap
//
//  Created by Fanni Szente on 28/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

struct UdacitySessionResponse: Codable {
    let account: Account
    let session: Session
}

struct Account: Codable {
    let registered: Bool
    let key: String
}

struct Session: Codable {
    let id: String
    let expiration: String
}
