//
//  UdacityLoginRequest.swift
//  OnTheMap
//
//  Created by Fanni Szente on 28/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

struct UdacityLoginRequest: Codable {
    let udacity: Udacity
}

struct Udacity: Codable {
    let username: String
    let password: String
}
