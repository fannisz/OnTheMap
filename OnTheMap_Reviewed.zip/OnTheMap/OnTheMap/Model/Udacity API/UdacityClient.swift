//
//  UdacityClient.swift
//  OnTheMap
//
//  Created by Fanni Szente on 27/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class UdacityClient {
    
    struct LoginResponse {
        static var accountKey = ""
        static var sessionId = ""
        static var errorMessage = ""
    }
    
    enum Endpoints {
        case getSessionId
        case signUpUdacity
        case deleteSession
        case getStudentData
        
        var stringValue: String {
            switch self {
            case .getSessionId:
                return "https://onthemap-api.udacity.com/v1/session"
            case .signUpUdacity:
                return "https://auth.udacity.com/sign-up"
            case .deleteSession:
                return "https://onthemap-api.udacity.com/v1/session"
            case .getStudentData:
                return "https://onthemap-api.udacity.com/v1/users/" + LoginResponse.accountKey
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func postRequestUdacity(username: String, password: String, completion: @escaping (Bool, Error?) -> Void) {
        var request = URLRequest(url: self.Endpoints.getSessionId.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let encoder = JSONEncoder()
        let body = UdacityLoginRequest(udacity: Udacity(username: username, password: password))
        request.httpBody = try! encoder.encode(body)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                return
            }
            let range = (5..<data!.count)
            let newData = data?.subdata(in: range)
            let decoder = JSONDecoder()
            do {
                let sessionResponse = try decoder.decode(UdacitySessionResponse.self, from: newData!)
                LoginResponse.accountKey = sessionResponse.account.key
                LoginResponse.sessionId = sessionResponse.session.id
                completion(true, nil)
            } catch {
                do {
                    let invalidCredentials = try decoder.decode(UdacityWrongCredentials.self, from: newData!)
                    completion(false, error)
                    LoginResponse.errorMessage = invalidCredentials.error
                } catch {
                    print("Probably network error")
                    completion(false, error)
                }
            }
        }
        task.resume()
    }
    
    class func deleteSession(completion: @escaping () -> Void) {
        var request = URLRequest(url: self.Endpoints.deleteSession.url)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
          if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
          request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil {
                return
            }
            LoginResponse.sessionId = ""
            completion()
        }
        task.resume()
    }
    
    class func getStudentData(completion: @escaping (UdacityPublicUserInformation, Error?) -> Void) {
        let request = URLRequest(url: Endpoints.getStudentData.url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                print(error?.localizedDescription)
                return
            }
            let range = (5..<data!.count)
            let newData = data?.subdata(in: range)
            let decoder = JSONDecoder()
            do {
                let studentInformation = try decoder.decode(UdacityPublicUserInformation.self, from: newData!)
                completion(studentInformation, nil)
            } catch {
                print(error.localizedDescription)
            }
        }
        task.resume()
    }
    
}

