//
//  UdacityPublicUserInformation.swift
//  OnTheMap
//
//  Created by Fanni Szente on 02/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class UdacityPublicUserInformation: Codable {
    let firstName: String
    let lastName: String
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
    }
}
