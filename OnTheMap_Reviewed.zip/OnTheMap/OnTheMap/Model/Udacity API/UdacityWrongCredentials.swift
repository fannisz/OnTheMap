//
//  UdacityWrongCredentials.swift
//  OnTheMap
//
//  Created by Fanni Szente on 28/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

struct UdacityWrongCredentials: Codable {
    let status: Float
    let error: String
}
