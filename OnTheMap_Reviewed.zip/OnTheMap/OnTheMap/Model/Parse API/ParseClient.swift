//
//  ParseClient.swift
//  OnTheMap
//
//  Created by Fanni Szente on 29/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class ParseClient {
    
    var studentPins = [StudentLocation]()
    
    enum Endpoints {
        
        static let base = "https://onthemap-api.udacity.com/v1/StudentLocation"
        static let limit = "limit="
        static let skip = "skip="
        static let order = "order="
        static let uniqueKey = "uniqueKey="
        
        case getStudentLocations
        case postStudentLocation
        
        var stringValue: String {
            switch self {
            case .getStudentLocations:
                return Endpoints.base + "?" + Endpoints.limit + "100" + "&" + Endpoints.order + "-updatedAt"
            case .postStudentLocation:
                return Endpoints.base
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
        
    }
    
    class func getStudentLocations(completion: @escaping (StudentLocation, Error?) -> Void) {
        let request = URLRequest(url: Endpoints.getStudentLocations.url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                return
            }
            print(String(data: data!, encoding: .utf8)!)
            let decoder = JSONDecoder()
            do {
                let studentLocations = try decoder.decode(StudentLocation.self, from: data!)
                completion(studentLocations, nil)
            } catch {
                print(error.localizedDescription)
            }
        }
        task.resume()
    }
    
    class func postStudentLocations(postInformation: PostLocation, completion: @escaping (Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.postStudentLocation.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let encoder = JSONEncoder()
        let body = try! encoder.encode(postInformation)
        request.httpBody = body
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                print(error?.localizedDescription)
                return
            }
            print("post request successful")
        }
        task.resume()
    }
    
}
