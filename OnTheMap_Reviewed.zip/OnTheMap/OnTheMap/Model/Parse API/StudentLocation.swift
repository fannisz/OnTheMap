//
//  StudentLocation.swift
//  OnTheMap
//
//  Created by Fanni Szente on 27/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class StudentLocation: Codable {
    
    let results: [Results]
    
}

class Results: Codable {
    
    let createdAt: String
    let firstName: String
    let lastName: String
    let latitude: Float
    let longitude: Float
    let mapString: String
    let mediaURL: String
    let objectId: String
    let uniqueKey: String
    let updatedAt: String
    
}
