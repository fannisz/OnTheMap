//
//  PostLocation.swift
//  OnTheMap
//
//  Created by Fanni Szente on 02/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import MapKit

class PostLocation: Codable {
    var uniqueKey: String
    var firstName: String
    var lastName: String
    var mapString: String
    var mediaURL: String
    var latitude: CLLocationDegrees
    var longitude: CLLocationDegrees
}
