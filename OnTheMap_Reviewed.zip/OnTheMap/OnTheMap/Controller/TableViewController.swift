//
//  TableViewController.swift
//  OnTheMap
//
//  Created by Fanni Szente on 29/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class TableViewController: UIViewController {
    
    
    //MARK: Outlets
    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var addPinButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var students: StudentLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ParseClient.getStudentLocations { (locations, error) in
            DispatchQueue.main.async {
                if error != nil {
                    let message = "Failed to download locations."
                    self.showDownloadFailure(message: message)
                } else {
                    self.students = locations
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        tableView.reloadData()
    }
    
    @IBAction func logoutSession(_ sender: UIButton) {
        UdacityClient.deleteSession {
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func refreshInformation(_ sender: UIButton) {
        ParseClient.getStudentLocations { (locations, error) in
            self.students = locations
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    func showDownloadFailure(message: String) {
        let alertVC = UIAlertController(title: "Download failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
    
    
}

extension TableViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students?.results.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.value2, reuseIdentifier: "cellId")
        let student = students?.results[indexPath.row]
        let firstName = student?.firstName ?? ""
        let lastName = student?.lastName ?? ""
        cell.textLabel?.text = firstName + " " + lastName
        cell.detailTextLabel?.text = student?.mediaURL
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let student = students?.results[indexPath.row]
        UIApplication.shared.open(URL(string: student!.mediaURL)!, options: [:])
    }
}
