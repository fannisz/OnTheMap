//
//  ConfirmLocationViewController.swift
//  OnTheMap
//
//  Created by Fanni Szente on 01/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class ConfirmLocationViewController: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    
    var latitude: CLLocationDegrees?
    var longitude: CLLocationDegrees?
    var searchedLocation: String?
    var mediaURL: String?
    var postLocationData: PostLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let pointAllocation = MKPointAnnotation()
        pointAllocation.coordinate = CLLocationCoordinate2DMake(CLLocationDegrees(latitude!), CLLocationDegrees(longitude!))
        let coordinateRegion = MKCoordinateRegion(center: pointAllocation.coordinate, latitudinalMeters: 800, longitudinalMeters: 800)
        pointAllocation.title = searchedLocation
        self.mapView.setRegion(coordinateRegion, animated: true)
        self.mapView.addAnnotation(pointAllocation)
        postLocationData?.latitude = self.latitude!
        postLocationData?.longitude = self.longitude!
        postLocationData?.mapString = self.searchedLocation!
        postLocationData?.uniqueKey = UdacityClient.LoginResponse.accountKey
        postLocationData?.mediaURL = self.mediaURL!
        UdacityClient.getStudentData { (response, error) in
            self.postLocationData?.firstName = response.firstName
            self.postLocationData?.lastName = response.lastName
        }
        print("viewDiDLoad")
    }
    
    @IBAction func goBack(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func postStudentLocation(_ sender: UIButton) {
        ParseClient.postStudentLocations(postInformation: postLocationData!) { (success, error) in
            if success {
                self.dismiss(animated: true, completion: nil)
            } else {
                let message = "There was a problem, please try again."
                DispatchQueue.main.async {
                    self.failurePostingLocation(message: message)
                }
            }
        }
    }
    
    func failurePostingLocation(message: String) {
        let alertVC = UIAlertController(title: "Posting failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
    
}
