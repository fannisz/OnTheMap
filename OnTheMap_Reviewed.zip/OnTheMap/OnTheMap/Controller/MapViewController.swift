//
//  MapViewController.swift
//  OnTheMap
//
//  Created by Fanni Szente on 27/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    //MARK: Outlets
    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var addPinButton: UIButton!
    @IBOutlet weak var refreshButton: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    
    //MARK: Overriding functions
    override func viewDidLoad() {
        super.viewDidLoad()
        ParseClient.getStudentLocations { (students, error) in
            let studentData = students.results
            for students in studentData {
                let pointAnnotation = MKPointAnnotation()
                pointAnnotation.coordinate = CLLocationCoordinate2DMake(CLLocationDegrees(students.latitude), CLLocationDegrees(students.longitude))
                pointAnnotation.title = students.firstName
                pointAnnotation.subtitle = students.mediaURL
                self.mapView.addAnnotation(pointAnnotation)
            }
        }
    }
    
    //MARK: Own functions
    @IBAction func logoutSession(_ sender: UIButton) {
        UdacityClient.deleteSession {
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                if !toOpen.contains("https") {
                    let message = "URL is not valid."
                    self.showErrorMessage(message: message)
                } else {
                    app.open(URL(string: toOpen)!, options: [:])
                }
            }
        }
    }
    
    @IBAction func refreshView(_ sender: UIButton) {
        ParseClient.getStudentLocations { (students, error) in
            let studentData = students.results
            for students in studentData {
                let pointAnnotation = MKPointAnnotation()
                pointAnnotation.coordinate = CLLocationCoordinate2DMake(CLLocationDegrees(students.latitude), CLLocationDegrees(students.longitude))
                pointAnnotation.title = students.firstName
                pointAnnotation.subtitle = students.mediaURL
                self.mapView.addAnnotation(pointAnnotation)
            }
        }
    }
    
    func showErrorMessage(message: String) {
        let alertVC = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
}
