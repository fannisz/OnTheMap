//
//  LoginViewController.swift
//  OnTheMap
//
//  Created by Fanni Szente on 26/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    
    // MARK: Setting up outlets
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    // MARK: Variables
    
    // MARK: Functions
    @IBAction func goToSignUp() {
        UIApplication.shared.open(UdacityClient.Endpoints.signUpUdacity.url, options: [:])
        }
    
    @IBAction func loginTapped() {
        let username = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        UdacityClient.postRequestUdacity(username: username, password: password, completion: handleSessionResponse(success:error:))
    }
    
    func handleSessionResponse(success: Bool, error: Error?) {
        DispatchQueue.main.async {
            if success {
                self.performSegue(withIdentifier: "loginComplete", sender: nil)
            } else {
                if UdacityClient.LoginResponse.errorMessage != "" {
                    self.showLoginFailure(message: UdacityClient.LoginResponse.errorMessage)
                } else {
                    self.showLoginFailure(message: "There has been a problem logging you in, please check your network connection.")
                }
            }
        }
    }
    
    func showLoginFailure(message: String) {
        let alertVC = UIAlertController(title: "Login failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
    
}
    

