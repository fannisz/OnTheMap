//
//  InformationPostingViewController.swift
//  OnTheMap
//
//  Created by Fanni Szente on 30/06/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class InformationPostingViewController: UIViewController {
    
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var linkTextField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBAction func cancelPosting(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func findLocation(_ sender: UIButton) {
        setSearchingLocation(true)
        if linkTextField.text == "" {
            let message = "Please enter a link to be displayed with a pin."
            self.failureFindLocation(message: message)
        } else {
            let searchRequest = MKLocalSearch.Request()
            searchRequest.naturalLanguageQuery = locationTextField.text ?? ""
            let search = MKLocalSearch(request: searchRequest)
            search.start { (response, error) in
                guard let response = response else {
                    DispatchQueue.main.async {
                        let message = "Location cannot be found, please check it again."
                        self.failureFindLocation(message: message)
                    }
                    return
                }
                let result = response.mapItems.first
                let latitude = result?.placemark.coordinate.latitude
                let longitude = result?.placemark.coordinate.longitude
                
                let controller: ConfirmLocationViewController
                controller = self.storyboard?.instantiateViewController(withIdentifier: "Confirm Location View Controller") as! ConfirmLocationViewController
                controller.latitude = latitude
                controller.longitude = longitude
                controller.searchedLocation = self.locationTextField.text!
                controller.mediaURL = self.linkTextField.text!
                self.setSearchingLocation(false)
                self.present(controller, animated: true, completion: nil)
                }
            }
        }
    
    func failureFindLocation(message: String) {
        let alertVC = UIAlertController(title: "Operation failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
    
    func setSearchingLocation(_ searchingLocation: Bool) {
        if searchingLocation == true {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
    }
    
}
